package main

import (
	"bufio"
	"encoding/hex"
	"fmt"
	"math/big"
	"os"
	"strings"

	"github.com/consensys/gnark-crypto/ecc"
	"github.com/consensys/gnark-crypto/ecc/bn254/fr"
	fr_bn254 "github.com/consensys/gnark-crypto/ecc/bn254/fr"
	"github.com/consensys/gnark/backend/groth16"
	"github.com/consensys/gnark/frontend"
	"github.com/consensys/gnark/frontend/cs/r1cs"
)

type Circuit struct {
	// timestamp var
	Pre_timestamp     frontend.Variable
	Current_timestamp frontend.Variable
	Now_time          frontend.Variable

	// block height var
	Pre_height     frontend.Variable
	Current_height frontend.Variable

	// block hash field var
	Parent_hash frontend.Variable `gnark:",public"`
	Prev_hash   frontend.Variable `gnark:",public"`

	// mix hash var
	Mix_hash frontend.Variable

	// uncle hash var
	Uncle_hash frontend.Variable

	// gas var
	Gas_limit frontend.Variable
	Gas_used  frontend.Variable

	// nonce var
	Nonce frontend.Variable

	// diffculty var
	Difficulty frontend.Variable
}

func height_check(api frontend.API, pre_height, current_height frontend.Variable) {
	expect_height := api.Add(pre_height, 1)
	api.AssertIsEqual(current_height, expect_height)
}

func timestamp_check(api frontend.API, pre_timestamp, current_timestamp, now_time frontend.Variable) {
	api.AssertIsLessOrEqual(pre_timestamp, current_timestamp)
	api.AssertIsDifferent(pre_timestamp, current_timestamp)
	api.AssertIsLessOrEqual(current_timestamp, now_time)
	api.AssertIsDifferent(current_timestamp, now_time)
}

func prevhash_check(api frontend.API, parent_hash, prev_hash frontend.Variable) {
	api.AssertIsEqual(parent_hash, prev_hash)
}

func unclehash_check(api frontend.API, uncle_hash frontend.Variable) {
	api.AssertIsEqual(uncle_hash, "0x1dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d49347")
}

func mixhash_check(api frontend.API, mix_hash frontend.Variable) {
	api.AssertIsEqual(mix_hash, "0x0")
}

func gaslimit_check(api frontend.API, gas_limit frontend.Variable, gas_used frontend.Variable) {
	api.AssertIsLessOrEqual(gas_limit, frontend.Variable((1<<63)-1))
	api.AssertIsLessOrEqual(gas_used, gas_limit)
}

func nonce_check(api frontend.API, nonce frontend.Variable) {
	api.AssertIsEqual(nonce, "0x0")
}

func difficulty_check(api frontend.API, difficulty frontend.Variable) {
	diffInTurn := frontend.Variable(2) // Block difficulty for in-turn signatures
	diffNoTurn := frontend.Variable(1) // Block difficulty for out-of-turn signatures
	api.AssertIsEqual(api.Mul(api.Sub(difficulty, diffInTurn), api.Sub(difficulty, diffNoTurn)), 0)
}

// Define declares the circuit's constraints
func (circuit *Circuit) Define(api frontend.API) error {
	height_check(api, circuit.Pre_height, circuit.Current_height)
	timestamp_check(api, circuit.Pre_timestamp, circuit.Current_timestamp, circuit.Now_time)
	prevhash_check(api, circuit.Parent_hash, circuit.Prev_hash)
	unclehash_check(api, circuit.Uncle_hash)
	mixhash_check(api, circuit.Mix_hash)
	gaslimit_check(api, circuit.Gas_limit, circuit.Gas_used)
	nonce_check(api, circuit.Nonce)
	difficulty_check(api, circuit.Difficulty)
	return nil
}

func main() {
	var circuit Circuit
	_r1cs, err := frontend.Compile(ecc.BN254.ScalarField(), r1cs.NewBuilder, &circuit)
	if err != nil {
		panic(err)
	}
	internal, secret, public := _r1cs.GetNbVariables()
	fmt.Printf("public, secret, internal %v, %v, %v\n", public, secret, internal)

	// 0. Read keys from files
	dataDir := "./key"
	pkFile, err := os.Open(dataDir + "/" + "pk.key")
	if err != nil {
		panic(err)
	}
	pk := groth16.NewProvingKey(ecc.BN254)
	bufReader := bufio.NewReaderSize(pkFile, 1024*1024)
	pk.UnsafeReadFrom(bufReader)
	defer pkFile.Close()
	vkFile, err := os.Open(dataDir + "/" + "vk.key")

	vk := groth16.NewVerifyingKey(ecc.BN254)
	vk.ReadFrom(vkFile)
	defer vkFile.Close()

	if err != nil {
		panic(err)
	}

	// 1. One time setup
	// groth16 zkSNARK: Setup
	// pk, vk, err := groth16.Setup(_r1cs)
	// if err != nil {
	// 	panic(err)
	// }

	// witness definition
	assignment := &Circuit{
		Pre_height:        101,
		Current_height:    102,
		Pre_timestamp:     20240825,
		Current_timestamp: 20240826,
		Now_time:          20240827,
		Parent_hash:       "0xa89c9362b8200c39ec24fadc310391e752f476fa91c407f6d3f5ff2e8bced15c",
		Prev_hash:         "0xa89c9362b8200c39ec24fadc310391e752f476fa91c407f6d3f5ff2e8bced15c",
		Uncle_hash:        "0x1dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d49347",
		Mix_hash:          "0x0",
		Gas_limit:         140000000,
		Gas_used:          8486644,
		Nonce:             "0x0",
		Difficulty:        2,
	}
	witness, _ := frontend.NewWitness(assignment, ecc.BN254.ScalarField())
	publicWitness, _ := witness.Public()
	fmt.Println("publicWitness:", publicWitness)

	// 2. Proof creation
	// groth16: Prove & Verify
	proof, err := groth16.Prove(_r1cs, pk, witness)
	fmt.Println("proof:", proof)
	if err != nil {
		panic(err)
	}
	// proof.WriteRawTo()

	// 3. Proof verification
	err2 := groth16.Verify(proof, vk, publicWitness)
	if err2 != nil {
		panic(err2)
	}

	// 3. Write solidity smart contract into a file
	// make temp dir
	// dirPath := "./contractDir/"
	// filePath := filepath.Join(dirPath, "verify.sol")

	// err = os.MkdirAll(dirPath, 0755)
	// if err != nil {
	// 	fmt.Println("Error creating directory:", err)
	// 	return
	// }

	// file, err := os.Create(filePath)
	// if err != nil {
	// 	fmt.Println("Error creating file:", err)
	// 	return
	// }

	// defer file.Close()
	// err = vk.ExportSolidity(file)
	// if err != nil {
	// 	panic(err)
	// }

	// 4. Write keys to files
	// dataDir := "./key"
	// os.MkdirAll(dataDir, 0755)
	// vkFile, err := os.Create(dataDir + "/" + "vk.key")
	// if err != nil {
	// 	panic(err)
	// }
	// defer vkFile.Close()
	// _, err = vk.WriteRawTo(vkFile)
	// if err != nil {
	// 	panic(err)
	// }
	// pkFile, err := os.Create(dataDir + "/" + "pk.key")
	// if err != nil {
	// 	panic(err)
	// }
	// defer pkFile.Close()
	// _, err = pk.WriteRawTo(pkFile)
	// if err != nil {
	// 	panic(err)
	// }

	//********************************************************************************************************************
	// 5. Exporting the proof to solidity

	// https://github.com/Consensys/gnark/blob/master/test/assert_solidity.go

	// len(vk.K) - 1 == len(publicWitness) + len(commitments)
	// numOfCommitments := vk.NbPublicWitness() - len(publicWitness.Vector().(fr_bn254.Vector))

	// proof to hex
	_proof, ok := proof.(interface{ MarshalSolidity() []byte })
	if !ok {
		panic("proof does not implement MarshalSolidity()")
	}

	proofStr := hex.EncodeToString(_proof.MarshalSolidity())

	// public witness to hex
	bPublicWitness, err := publicWitness.MarshalBinary()
	if err != nil {
		panic(err)
	}
	// that's quite dirty...
	// first 4 bytes -> nbPublic
	// next 4 bytes -> nbSecret
	// next 4 bytes -> nb elements in the vector (== nbPublic + nbSecret)
	bPublicWitness = bPublicWitness[12:]
	publicWitnessStr := hex.EncodeToString(bPublicWitness)

	// https://github.com/Consensys/gnark-solidity-checker/blob/main/cmd/templates.go

	proofHex := proofStr
	inputHex := publicWitnessStr
	nbPublicInputs := len(publicWitness.Vector().(fr_bn254.Vector))
	fpSize := 4 * 8

	proofBytes, err := hex.DecodeString(proofHex)
	if err != nil {
		panic(err)
	}

	if len(proofBytes) != fpSize*8 {
		panic("proofBytes != fpSize*8")
	}

	inputBytes, err := hex.DecodeString(inputHex)
	if err != nil {
		panic(err)
	}

	if len(inputBytes)%fr.Bytes != 0 {
		panic("inputBytes mod fr.Bytes !=0")
	}

	// convert public inputs
	nbInputs := len(inputBytes) / fr.Bytes
	if nbInputs != nbPublicInputs {
		panic("nbInputs != nbPublicInputs")
	}
	input := make([]*big.Int, nbPublicInputs)
	for i := 0; i < nbInputs; i++ {
		var e fr.Element
		e.SetBytes(inputBytes[fr.Bytes*i : fr.Bytes*(i+1)])
		input[i] = new(big.Int)
		e.BigInt(input[i])
	}

	// solidity contract inputs
	var __proof [8]*big.Int

	// proof.Ar, proof.Bs, proof.Krs
	for i := 0; i < 8; i++ {
		__proof[i] = new(big.Int).SetBytes(proofBytes[fpSize*i : fpSize*(i+1)])
	}

	var finalproof []string
	var finalinput []string

	for _, bi := range __proof {
		finalproof = append(finalproof, bi.String())
	}
	for _, bi := range input {
		finalinput = append(finalinput, bi.String())
	}
	result := "[" + strings.Join(finalproof, ",") + "]," + "[" + strings.Join(finalinput, ",") + "]"

	fmt.Println("result: ", result)
}
